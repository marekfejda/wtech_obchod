<footer class="py-2 mt-auto" style="background-color: #DBD9DB;">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center flex-wrap w-100 px-4 text-start">
            <div class="d-flex flex-column flex-sm-row gap-2 gap-sm-3">
                <a href="{{ route('about') }}" class="text-decoration-none" style="color: #45503B;">O nás</a>
                <a href="{{ route('contact') }}" class="text-decoration-none" style="color: #45503B;">Kontakt</a>
            </div>
        </div>
    </div>
</footer>