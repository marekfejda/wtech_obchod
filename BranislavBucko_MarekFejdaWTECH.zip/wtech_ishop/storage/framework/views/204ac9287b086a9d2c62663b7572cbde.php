<?php $__env->startSection('title', 'iSHOP - Pridaj Produkt'); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('pages/admin_add/styles.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div id="flash-message" class="alert alert-success alert-dismissible fade show text-center" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>

        <script>
            setTimeout(function () {
                let el = document.getElementById('flash-message');
                if (el) {
                    el.style.transition = 'opacity 0.5s ease';
                    el.style.opacity = 0;
                    setTimeout(() => el.remove(), 500);
                }
            }, 3000); // 3 sekundy
        </script>
    <?php endif; ?>

    <div class="container my-5 px-3 px-sm-5">
        <form id="addProductForm" class="row g-4" method="POST" action="<?php echo e(route('admin.store_product')); ?>" enctype="multipart/form-data" novalidate>
            <?php echo csrf_field(); ?>

            <!-- Left Column -->
            <div class="col-md-6">
                <input id="name" name="name" type="text" class="form-control mb-3 rounded-pill" placeholder="Meno produktu">
                <textarea id="short_description" name="short_description" class="form-control mb-3 rounded-4" rows="6" placeholder="Titulný popis produktu"></textarea>
                <textarea id="description" name="description" class="form-control mb-3 rounded-4" rows="6" placeholder="Popis produktu"></textarea>
            </div>

            <!-- Right Column -->
            <div class="col-md-6">
                <!-- Category -->
                <select id="category_id" name="category_id" class="form-select mb-3 rounded-pill">
                    <option value="" selected disabled>Kategória</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <!-- Color -->
                <select id="color_id" name="color_id" class="form-select mb-3 rounded-pill">
                    <option value="" selected disabled>Farba</option>
                    <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($color->id); ?>"><?php echo e($color->color); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <!-- Brand -->
                <select id="brand_id" name="brand_id" class="form-select mb-3 rounded-pill">
                    <option value="" selected disabled>Značka</option>
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->brand); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <!-- Price and Quantity -->
                <input id="price" name="price" type="number" step="0.01" class="form-control mb-3 rounded-pill" min="0" placeholder="Cena">
                <input id="stockQuantity" name="stockQuantity" type="number" class="form-control mb-3 rounded-pill" min="0" placeholder="Skladom ks">

                <!-- File Input -->
                <div class="mb-3">
                    <label for="productPhotos" class="btn btn-outline-dark rounded-pill">Pridať fotky</label>
                    <input name="images[]" type="file" class="form-control d-none" id="productPhotos" accept="image/*" multiple>
                </div>

                <!-- Image Previews -->
                <div id="previewContainer" class="d-flex flex-wrap gap-2 mb-3"></div>

                <!-- Submit Button -->
                <div class="text-end">
                    <button type="submit" class="btn btn-primary rounded-pill button_color">Pridať produkt</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('pages/admin_add/scripts.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marek\Documents\FIIT\wtech_obchod\wtech_ishop\resources\views/pages/admin_add.blade.php ENDPATH**/ ?>