<?php $__env->startSection('title', 'iSHOP - ' . ($category->category ?? 'Kategória')); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('pages/category/styles.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-header-button'); ?>
    <button id="sideBarBut" class="btn btn-outline-dark d-md-none">
        <i class="bi bi-list"></i>
    </button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper -->
    <div class="d-flex w-100">
        <!-- Sidebar -->
        <nav id="sidebarMenu" class="col-lg-2 collapse d-md-block p-3" style="background-color: #E5EBEA;">
            <ul class="nav flex-column">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link sidebar-category rounded-pill" style="color: #45503B;"
                            href="<?php echo e(route('category', $category->slug)); ?>">
                            <i class="bi bi-<?php echo e($category->icon); ?>"></i> <?php echo e($category->category); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>

        <!-- Main content -->
        <main class="col-lg-10 p-4 flex-grow-1">
            <!-- Filters -->
            <div class="d-flex flex-wrap align-items-end responsive-gap mb-4">

                <!-- Cena (from-to) -->
                <form id="filterForm" method="GET" action="<?php echo e(route('category', ['slug' => $currentCategory->slug])); ?>">
                    <!-- Aktuálne zoradenie -->
                    <input type="hidden" name="sort" value="<?php echo e(request('sort', 'id_asc')); ?>">

                    <!-- Aktuálne vybraté farby -->
                    <?php $__currentLoopData = request('colors', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colorId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="colors[]" value="<?php echo e($colorId); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Aktuálne vybraté značky -->
                    <?php $__currentLoopData = request('brands', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brandId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="brands[]" value="<?php echo e($brandId); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Cena (from-to) -->
                    <div>
                        <label for="priceRange" class="form-label">Cena</label>
                        <div class="input-group">
                            <input
                                type="number"
                                class="form-control rounded-pill"
                                step="0.01"
                                placeholder="od"
                                id="priceFrom"
                                name="price_min"
                                value="<?php echo e(request('price_min', 0)); ?>"
                                min="0"
                                max="<?php echo e(request('price_max', $maxPrice)); ?>"
                            >
                            <span class="input-group-text border-0 bg-transparent rounded-pill">-</span>
                            <input
                                type="number"
                                class="form-control rounded-pill"
                                step="0.01"
                                placeholder="do"
                                id="priceTo"
                                name="price_max"
                                value="<?php echo e(request('price_max', $maxPrice)); ?>"
                                min="<?php echo e(request('price_min', 0)); ?>"
                                max="<?php echo e($maxPrice); ?>"
                            >
                        </div>
                    </div>

                    <!-- Skryté submit tlačidlo pre Enter -->
                    <button type="submit" hidden></button>
                </form>

                <form method="GET" action="<?php echo e(route('category', ['slug' => $currentCategory->slug])); ?>">
                    <input type="hidden" name="sort" value="<?php echo e(request('sort', 'id_asc')); ?>">

                    <div class="d-flex flex-wrap gap-4">
                        <!-- Farba dropdown -->
                        <div class="dropdown">
                            <label class="form-label d-block">Farba</label>
                            <button class="btn btn-outline-secondary dropdown-toggle rounded-pill button_color_dif dropdown-toggle-color"
                                    type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                Vyber farby
                            </button>

                            <ul class="dropdown-menu dropdown-menu-color p-2" style="min-width: 200px;">
                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <label class="form-check-label">
                                            <input
                                                class="form-check-input me-1"
                                                type="checkbox"
                                                name="colors[]"
                                                value="<?php echo e($color->id); ?>"
                                                <?php echo e(in_array($color->id, request()->input('colors', [])) ? 'checked' : ''); ?>>
                                            <?php echo e($color->color); ?>

                                        </label>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li class="mt-2 text-center">
                                    <button type="submit" class="btn button_color btn-sm btn-primary rounded-pill px-4">Filtrovať</button>
                                </li>
                            </ul>
                        </div>

                        <!-- Značka dropdown -->
                        <div class="dropdown">
                            <label class="form-label d-block">Značka</label>
                            <button class="btn btn-outline-secondary dropdown-toggle rounded-pill button_color_dif dropdown-toggle-brand"
                                    type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                Vyber značky
                            </button>

                            <ul class="dropdown-menu dropdown-menu-brand p-2" style="min-width: 200px;">
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <label class="form-check-label">
                                            <input
                                                class="form-check-input me-1"
                                                type="checkbox"
                                                name="brands[]"
                                                value="<?php echo e($brand->id); ?>"
                                                <?php echo e(in_array($brand->id, request()->input('brands', [])) ? 'checked' : ''); ?>>
                                            <?php echo e($brand->brand); ?>

                                        </label>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li class="mt-2 text-center">
                                    <button type="submit" class="btn button_color btn-sm btn-primary rounded-pill px-4">Filtrovať</button>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <input type="hidden" name="price_min" value="<?php echo e(request('price_min', 0)); ?>">
                    <input type="hidden" name="price_max" value="<?php echo e(request('price_max', $maxPrice)); ?>">
                </form>


                <!-- Sorting -->
                <?php
                    $query = [
                        'sort' => $sort === 'price_asc' ? 'price_desc' : 'price_asc',
                        'colors' => request('colors', []),
                        'brands' => request('brands', []),
                        'price_min' => request('price_min', 0),
                        'price_max' => request('price_max', $maxPrice),
                    ];

                    // Vygeneruj URL
                    $sortUrl = route('category', ['slug' => $currentCategory->slug]) . '?' . http_build_query($query);
                ?>

                <div class="ms-auto d-flex align-items-center">
                    <span class="form-label mb-0 me-1">Cena</span>
                    <a href="<?php echo e($sortUrl); ?>">


                        <i id="sortIcon"
                        class="bi <?php echo e($sort === 'price_asc' ? 'bi-chevron-up' : ($sort === 'price_desc' ? 'bi-chevron-down' : 'bi-code' )); ?>"
                        style="cursor: pointer; color: #000;">
                        </i>
                    </a>
                </div>


            </div>

            <!-- Product List -->
            <div class="row">
                <?php if($products->isEmpty()): ?>
                    <div class="d-flex justify-content-center align-items-center" style="height: 300px;">
                        <p class="text-muted fs-4 m-0">Vyhľadávaniu nevyhovujú žiadne produkty</p>
                    </div>
                <?php endif; ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-lg-4 col-md-6 mb-4 d-flex justify-content-center">
                        <a href="<?php echo e(route('detail', $product->id)); ?>" class="text-decoration-none">
                            <div class="card product-card h-100 p-3 border rounded-4 d-flex flex-column flex-md-row"
                                style="min-height: 250px; max-width: 380px; width: 100%; cursor: pointer;">
                                <!-- Left: Image + Price -->
                                <div class="d-flex flex-column align-items-center mb-3 mb-md-0 w-100 w-md-50 pe-md-3">
                                    <div class="image-container d-flex align-items-end p-2 mb-2"
                                        style="width: 100%; height: 140px; overflow: hidden;">
                                        <?php
                                            $firstImage = $product->images->first();
                                        ?>

                                        <?php if($firstImage): ?>
                                            <img src="<?php echo e(asset($firstImage->path)); ?>" class="product-img"
                                                alt="<?php echo e($product->name); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('assets/favicon.png')); ?>" class="product-img"
                                                alt="Bez obrázka">
                                        <?php endif; ?>
                                    </div>
                                    <div class="fw-bold fs-6 text-center text-color"><?php echo e(number_format($product->price, 2)); ?> €</div>
                                </div>

                                <!-- Right: Name + Description -->
                                 <?php
                                    $desc = $product->short_description;
                                    $diff = 50 - strlen($desc);
                                    if ($diff > 0) {
                                        $desc .= str_repeat("\u{00A0} ", $diff); // Adds non-breaking spaces
                                    }
                                ?>
                                <div class="d-flex flex-column justify-content-center w-100 w-md-50">
                                    <div class="fw-semibold fs-5 mb-1 text-color"><?php echo e($product->name); ?></div>
                                    <div class="text-muted small text-color"><?php echo $desc; ?></div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Page counter -->
            <?php
                $currentPage = $products->currentPage();
                $lastPage = $products->lastPage();
            ?>

            <?php if($lastPage > 1): ?>
                <nav aria-label="Product pagination" class="d-flex justify-content-center mt-4">
                    <ul class="pagination responsive-pagination">
                        <?php for($i = 1; $i <= min(9, $lastPage); $i++): ?>
                            <li class="page-item <?php echo e($i == $currentPage ? 'active' : ''); ?>">
                                <a class="page-link" href="<?php echo e($products->url($i)); ?>"><?php echo e($i); ?></a>
                            </li>
                        <?php endfor; ?>

                        <?php if($lastPage > 9): ?>
                            <li class="page-item disabled"><span class="page-link">...</span></li>
                            <li class="page-item <?php echo e($lastPage == $currentPage ? 'active' : ''); ?>">
                                <a class="page-link" href="<?php echo e($products->url($lastPage)); ?>"><?php echo e($lastPage); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if($lastPage > 10 && $currentPage < $lastPage): ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>" aria-label="Next">
                                    <span aria-hidden="true">&rsaquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        </main>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('pages/category/scripts.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marek\Documents\FIIT\wtech_obchod\wtech_ishop\resources\views/pages/category.blade.php ENDPATH**/ ?>