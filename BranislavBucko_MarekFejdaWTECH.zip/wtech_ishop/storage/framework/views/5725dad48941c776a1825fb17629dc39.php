<?php $__env->startSection('title', 'iSHOP - Kontakt'); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('pages/contact/styles.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- About Us Section -->
    <div class="container my-5">
        <!-- Title -->
        <h1 class="text-center mb-4 text-color">Kontakt</h1>

        <!-- About Us Text Block -->
        <div class="bg-light p-5 rounded-4 text-start">
            <p class="fs-4 text-color"><b>Email:</b> informacie@obchod.sk</p>
            <p class="fs-4 text-color"><b>Telefon:</b> 0903 123 123</p>
            <p class="fs-4 text-color"><b>Adresa:</b> Súmračná 25, 821 02 Bratislava</p>
            <p class="fs-4 text-color"><b>IČO:</b> 496 498 196</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('pages/contact/scripts.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marek\Documents\FIIT\wtech_obchod\wtech_ishop\resources\views/pages/contact.blade.php ENDPATH**/ ?>