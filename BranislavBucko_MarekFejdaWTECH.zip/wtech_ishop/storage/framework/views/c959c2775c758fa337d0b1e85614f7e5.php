<?php $__env->startSection('title', 'iSHOP - Môj Účet'); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('pages/account/styles.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <div id="flash-message" class="alert alert-success alert-dismissible fade show text-center" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>

        <script>
            setTimeout(function () {
                let el = document.getElementById('flash-message');
                if (el) {
                    el.style.transition = 'opacity 0.5s ease';
                    el.style.opacity = 0;
                    setTimeout(() => el.remove(), 500);
                }
            }, 3000); // 3 sekundy
        </script>
    <?php endif; ?>

    
    <!-- User/Admin Screen -->
    <div class="container d-flex align-items-center justify-content-center flex-grow-1 flex-column">

        <!-- User Icon -->
        <div class="text-center mb-4">
            <i class="bi bi-person-circle" style="font-size: 5rem; color: #45503B;"></i>
        </div>

        <?php
            $user = session('user');
        ?>

        <?php if($user && $user->role === 'admin'): ?>
            <!-- Admin Buttons -->
            <div class="d-flex flex-column align-items-center mb-3">
                <a href="<?php echo e(route('admin.add')); ?>" class="btn btn-primary rounded-pill button_color mb-2">
                    Pridať produkt
                </a>

                <a href="<?php echo e(route('admin.delete')); ?>" class="btn btn-primary rounded-pill button_color">
                    Odstrániť produkt
                </a>
            </div>
        <?php endif; ?>



        <!-- Logout Button -->
        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger mb-3 rounded-pill">Odhlásiť sa</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('pages/account/scripts.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marek\Documents\FIIT\wtech_obchod\wtech_ishop\resources\views/pages/account.blade.php ENDPATH**/ ?>