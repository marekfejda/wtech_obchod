<?php $__env->startSection('title', 'iSHOP'); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('pages/index/styles.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-header-button'); ?>
    <button id="sideBarBut" class="btn btn-outline-dark d-md-none">
        <i class="bi bi-list"></i>
    </button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper -->
    <div class="d-flex flex-grow-1" style="min-height: 0;">
        <!-- Sidebar -->
        <nav id="sidebarMenu" class="col-lg-2 collapse d-md-block p-3" style="background-color: #E5EBEA;">
            <ul class="nav flex-column">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link sidebar-category rounded-pill" style="color: #45503B;"
                            href="<?php echo e(route('category', $category->slug)); ?>">
                            <i class="bi bi-<?php echo e($category->icon); ?>"></i> <?php echo e($category->category); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>

        <!-- Main content -->
        <main class="col-lg-10 p-4">
            <!-- Banner Section -->
            <div class="container-fluid px-0 mb-4">
                <img src="<?php echo e(asset('assets/banner.png')); ?>" alt="Banner" class="img-fluid w-100 rounded-4"
                    style="max-height: 300px; object-fit: cover;">
            </div>

            <div class="container">
                <div class="row">
                    <?php if($products->isEmpty()): ?>
                        <div class="d-flex justify-content-center align-items-center" style="height: 300px;">
                            <p class="text-muted fs-4 m-0">Vyhľadávaniu nevyhovujú žiadne produkty</p>
                        </div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="col-xl-3 col-lg-4 col-md-6 mb-4">
                            <div class="card product-card rounded-4">
                                <div class="image-container">
                                    <a href="<?php echo e(route('detail', $product->id)); ?>">
                                        <?php
                                            $firstImage = $product->images->first();
                                        ?>

                                        <?php if($firstImage): ?>
                                            <img src="<?php echo e(asset($firstImage->path)); ?>" class="card-img-top"
                                                alt="<?php echo e($product->name); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('assets/favicon.png')); ?>" class="card-img-top"
                                                alt="Bez obrázka">
                                        <?php endif; ?>
                                    </a>
                                </div>
                                <div class="card-body">
                                    <div class="text-container">
                                        <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                        <p class="card-text fw-bold"><?php echo e(number_format($product->price, 2)); ?> €</p>
                                    </div>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <!-- Page counter -->
            <?php
                $isPaginated = $products instanceof \Illuminate\Pagination\LengthAwarePaginator;
            ?>

            <?php if($isPaginated): ?>
                <?php
                    $currentPage = $products->currentPage();
                    $lastPage = $products->lastPage();
                ?>

                <?php if($lastPage > 1): ?>
                    <nav aria-label="Product pagination" class="d-flex justify-content-center mt-4">
                        <ul class="pagination responsive-pagination">
                            <?php for($i = 1; $i <= min(9, $lastPage); $i++): ?>
                                <li class="page-item <?php echo e($i == $currentPage ? 'active' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($products->url($i)); ?>"><?php echo e($i); ?></a>
                                </li>
                            <?php endfor; ?>

                            <?php if($lastPage > 9): ?>
                                <li class="page-item disabled"><span class="page-link">...</span></li>
                                <li class="page-item <?php echo e($lastPage == $currentPage ? 'active' : ''); ?>">
                                    <a class="page-link" href="<?php echo e($products->url($lastPage)); ?>"><?php echo e($lastPage); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if($lastPage > 10 && $currentPage < $lastPage): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>" aria-label="Next">
                                        <span aria-hidden="true">&rsaquo;</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('pages/index/scripts.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marek\Documents\FIIT\wtech_obchod\wtech_ishop\resources\views/pages/index.blade.php ENDPATH**/ ?>