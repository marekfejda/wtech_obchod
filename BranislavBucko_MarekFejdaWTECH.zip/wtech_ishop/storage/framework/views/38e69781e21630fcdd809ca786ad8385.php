<?php $__env->startSection('title', 'iSHOP - Hotovo!'); ?>

<?php $__env->startSection('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('pages/cart4/styles.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Confirmation Message -->
    <div class="confirmation-message">
        <h2 style="color: #45503B;">Ďakujeme za objednávku!</h2>
        <img src="<?php echo e(asset('assets/icons/checkmark.png')); ?>" style="color: #45503B;" alt="Checkmark" class="checkmark">
        <h5 class="mt-5" style="color: #45503B;">Vaša objednávka číslo <?php echo e($order->id); ?> bola úspešne odoslaná a spracovaná.</h5>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page-js'); ?>
    <script src="<?php echo e(asset('pages/cart4/scripts.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marek\Documents\FIIT\wtech_obchod\wtech_ishop\resources\views/pages/cart4.blade.php ENDPATH**/ ?>